#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"

// gcc -Wall -std=c99 -lm *.c -o tp2
// ./tp2 reviews.txt termos_positivos.txt termos_negativos.txt


int main(int *argc, char **argv){

    FILE *file_reviews = fopen(argv[1], "r"); 
    if (file_reviews == NULL){
        printf("Erro ao abrir o primeiro arquivo.\n");
        return 0;
    }

    int linhas_reviews;
    Restaurante *restaurantes = insere_restaurantes(file_reviews, &linhas_reviews);
    rewind(file_reviews);
    fclose(file_reviews);


    // Abrindo arquivo com os termos positivos

    FILE *file_positivos = fopen(argv[2], "r"); 
    if (file_positivos == NULL){
        printf("Erro ao abrir o segundo arquivo.\n");
        return 0;
    }

    int tam_positivos;
    restaurantes = insere_positivos(restaurantes, linhas_reviews, file_positivos, &tam_positivos);


    // Abrindo o arquivo com os termos negativos 
    FILE *file_negativos = fopen(argv[3], "r");
    if (file_negativos == NULL){
        printf("Erro ao abrir o terceiro arquivo.\n");
        return 0;
    }

    int tam_negativos;
    restaurantes = insere_negativos(restaurantes, linhas_reviews, file_negativos, &tam_negativos);


    rewind(file_negativos);
    rewind(file_positivos);

    fclose(file_positivos);

    fclose(file_negativos);

    restaurantes = conta_ocorrencias(restaurantes, linhas_reviews, tam_positivos, tam_negativos);

    gera_arquivos_saida(restaurantes, linhas_reviews, tam_positivos, tam_negativos);

    free(restaurantes);

    return 0;
}