#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct histograma{
    char *termo;
    int ocorrencias;
} Histograma;


typedef struct restaurante{
    char nome[100];
    float numero_estrelas;
    char avaliacao[500];
    Histograma *termos_positivos;
    Histograma *termos_negativos;
} Restaurante;


Restaurante* insere_restaurantes();

Restaurante* insere_positivos(Restaurante *restaurantes, int linhas_reviews, FILE *file_positivos, int *tam_positivos);

Restaurante* insere_negativos(Restaurante *restaurantes, int linhas_reviews, FILE *file_negativos, int *tam_negativos);

Restaurante* conta_ocorrencias(Restaurante *restaurantes, int numero_restaurantes, int tam_positivos, int tam_negativos);

void insere_saida_positiva(Restaurante restaurante, int tam_positivos, int tam_negativos, FILE *saida_pos, int quant_positivos, int quant_negativos);

void insere_saida_negativa(Restaurante restaurante, int tam_positivos, int tam_negativos, FILE *saida_neg, int quant_positivos, int quant_negativos);

void insere_saida_neutra(Restaurante restaurante, int tam_positivos, int tam_negativos, FILE *saida_neutros, int quant_positivos, int quant_negativos);


void gera_arquivos_saida(Restaurante *restaurantes, int linhas_reviews, int tam_positivos, int tam_negativos);