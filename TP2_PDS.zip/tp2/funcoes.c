#include "funcoes.h"

// Função que armazena as informações dos restaurantes em um vetor de objetos 'restaurante'

Restaurante* insere_restaurantes(FILE *file_reviews, int *linhas_reviews){
    fscanf(file_reviews, "%d\n", linhas_reviews);
    Restaurante *restaurantes = (Restaurante*) malloc((*linhas_reviews) * sizeof(Restaurante));

    for (int i = 0; i < *linhas_reviews; i++){
        fscanf(file_reviews, "%[^;];%f;%[^\n]\n", restaurantes[i].nome, &restaurantes[i].numero_estrelas, restaurantes[i].avaliacao);

    }
    return restaurantes;
}


// Função que coloca os termos positivos no atributo 'positivos' de restaurante

Restaurante* insere_positivos(Restaurante *restaurantes, int linhas_reviews, FILE *file_positivos, int *tam_positivos){
    for (int i = 0; i < linhas_reviews; i++){
        fscanf(file_positivos, "%d\n", tam_positivos);
        restaurantes[i].termos_positivos = (Histograma*) malloc((*tam_positivos) * sizeof(Histograma));
        for(int j = 0; j < *tam_positivos; j++){
            restaurantes[i].termos_positivos[j].termo = (char*) malloc(50 * sizeof(char));
            fscanf(file_positivos, "%s\n", restaurantes[i].termos_positivos[j].termo);
            restaurantes[i].termos_positivos[j].ocorrencias = 0;
        }
        rewind(file_positivos);
    }
    return restaurantes;
}


// Função que coloca os termos negativos no atributo 'negativos' de restaurante

Restaurante* insere_negativos(Restaurante *restaurantes, int linhas_reviews, FILE *file_negativos, int *tam_negativos){
        for (int i = 0; i < linhas_reviews; i++){
        fscanf(file_negativos, "%d\n", tam_negativos);
        restaurantes[i].termos_negativos = (Histograma*) malloc((*tam_negativos) * sizeof(Histograma));
        for(int j = 0; j < *tam_negativos; j++){
            restaurantes[i].termos_negativos[j].termo = (char*) malloc(50 * sizeof(char));
            fscanf(file_negativos, "%s\n", restaurantes[i].termos_negativos[j].termo);
            restaurantes[i].termos_negativos[j].ocorrencias = 0;
        }
        rewind(file_negativos);
    }
    return restaurantes;
}


// Função que conta as ocorrências dos termos de avaliacao em termos_positivos e termos_negativos dos objetos de 'restaurantes' 

Restaurante* conta_ocorrencias(Restaurante *restaurantes, int numero_restaurantes, int tam_positivos, int tam_negativos){
    for(int i = 0; i < numero_restaurantes; i++){
        int aux = 0;
        while(restaurantes[i].avaliacao[aux] != '\0'){
            int aux2 = 0;
            // Se estiver entre 65 e 90, o caracter é letra maiúscula
            if (restaurantes[i].avaliacao[aux] >= 65 && restaurantes[i].avaliacao[aux] <= 90){
                // colocando em minúsculo
                restaurantes[i].avaliacao[aux] = restaurantes[i].avaliacao[aux] + 32;
            }
            // Se não for alguma letra do alfabeto (caracteres menores que 65, ou maiores que 122 ou no intervalo (90, 97)) sai e vai pra próxima iteração
            if (restaurantes[i].avaliacao[aux] < 97 && restaurantes[i].avaliacao[aux] > 90){
                aux++;
                continue;
            }
            else if (restaurantes[i].avaliacao[aux] > 122 || restaurantes[i].avaliacao[aux] < 65){
                aux++;
                continue;
            }

            char *palavra = (char*) malloc(50 * sizeof(char));
            while(restaurantes[i].avaliacao[aux] >= 97 && restaurantes[i].avaliacao[aux] <= 122){
                palavra[aux2] = restaurantes[i].avaliacao[aux];
                aux2++;
                aux++;
            }
            
            palavra[aux2] = '\0';

            // variável auxiliar para informar se a palavra já foi encontrada entre os termos positivos
            int encontrada = 0;
            for (int j = 0; j < tam_positivos; j++){
                if(strcmp(palavra, restaurantes[i].termos_positivos[j].termo) == 0){
                    restaurantes[i].termos_positivos[j].ocorrencias++;
                    encontrada = 1;
                    break;
                }
            }
            if (encontrada == 0){
                for (int j = 0; j < tam_negativos; j++){
                    if(strcmp(palavra, restaurantes[i].termos_negativos[j].termo) == 0){
                        restaurantes[i].termos_negativos[j].ocorrencias++;
                        encontrada = 1;
                        break;
                    }
                }
            }
            free(palavra);
        }

    }
    return restaurantes;
}

// Função que pega um objeto do tipo restaurante e insere suas informações no aquivo "saida_pos"
void insere_saida_positiva(Restaurante restaurante, int tam_positivos, int tam_negativos, FILE *saida_pos, int quant_positivos, int quant_negativos){
            fprintf(saida_pos, "%s\t%d\t%d\t", restaurante.nome, quant_positivos, quant_negativos);
            for(int j = 0; j < tam_positivos; j++){
                if (restaurante.termos_positivos[j].ocorrencias != 0){
                    fprintf(saida_pos, "%s: %d; ", restaurante.termos_positivos[j].termo, restaurante.termos_positivos[j].ocorrencias);
                }
            }
              for(int j = 0; j < tam_negativos; j++){
                if (restaurante.termos_negativos[j].ocorrencias != 0){
                    fprintf(saida_pos, "%s: %d; ", restaurante.termos_negativos[j].termo, restaurante.termos_negativos[j].ocorrencias);
                }
            }
            fprintf(saida_pos, "\n");
            
}

// Função que pega um objeto do tipo restaurante e insere suas informações no aquivo "saida_neg"
void insere_saida_negativa(Restaurante restaurante, int tam_positivos, int tam_negativos, FILE *saida_neg, int quant_positivos, int quant_negativos){
    fprintf(saida_neg, "%s\t%d\t%d\t", restaurante.nome, quant_positivos, quant_negativos);
    for(int j = 0; j < tam_positivos; j++){
        if (restaurante.termos_positivos[j].ocorrencias != 0){
            fprintf(saida_neg, "%s: %d; ", restaurante.termos_positivos[j].termo, restaurante.termos_positivos[j].ocorrencias);
        }
    }
    for(int j = 0; j < tam_negativos; j++){
        if (restaurante.termos_negativos[j].ocorrencias != 0){
            fprintf(saida_neg, "%s: %d; ", restaurante.termos_negativos[j].termo, restaurante.termos_negativos[j].ocorrencias);
        }
    }
    fprintf(saida_neg, "\n");
}

// Função que pega um objeto do tipo restaurante e insere suas informações no aquivo "saida_neutros"
void insere_saida_neutra(Restaurante restaurante, int tam_positivos, int tam_negativos, FILE *saida_neutros, int quant_positivos, int quant_negativos){
    fprintf(saida_neutros, "%s\t%d\t%d\t", restaurante.nome, quant_positivos, quant_negativos);
    for(int j = 0; j < tam_positivos; j++){
        if (restaurante.termos_positivos[j].ocorrencias != 0){
            fprintf(saida_neutros, "%s: %d; ", restaurante.termos_positivos[j].termo, restaurante.termos_positivos[j].ocorrencias);
        }
    }
    for(int j = 0; j < tam_negativos; j++){
        if (restaurante.termos_negativos[j].ocorrencias != 0){
            fprintf(saida_neutros, "%s: %d; ", restaurante.termos_negativos[j].termo, restaurante.termos_negativos[j].ocorrencias);
        }
    }
    fprintf(saida_neutros, "\n");
}


// Função que gera os arquivos de saída e armazena neles os resultados obtidos

void gera_arquivos_saida(Restaurante *restaurantes, int linhas_reviews, int tam_positivos, int tam_negativos){

    FILE *saida_pos = fopen("positivos.txt", "w");
    if (saida_pos == NULL){
        printf("Não foi possível abrir o arquivo positivos.txt.\n");
        return;
    }

    FILE *saida_neg = fopen("negativos.txt", "w");
    if (saida_neg == NULL){
        printf("Não foi possível abrir o arquivo negativos.txt.\n");
        return;
    }

    FILE *saida_neutros = fopen("neutros.txt", "w");
    if (saida_neutros == NULL){
        printf("Não foi possível abrir o arquivo neutros.txt.\n");
        return;
    }

    // Variáveis para guardar as informações que serão impressas no terminal ao final da função
    int corretos = 0, incorretos = 0;
    char **class_corretos = (char**) malloc(linhas_reviews * sizeof(char*));
    char **class_incorretos = (char**) malloc(linhas_reviews * sizeof(char*));

    // Percorrendo todos os restaurantes e imprimindo os resultados nos arquivos
    for(int i = 0; i < linhas_reviews; i++){

        int quant_positivos = 0, quant_negativos = 0;
        for(int j = 0; j < tam_positivos; j++){
            quant_positivos += restaurantes[i].termos_positivos[j].ocorrencias;
        }
        for(int j = 0; j < tam_negativos; j++){
            quant_negativos += restaurantes[i].termos_negativos[j].ocorrencias;
        }

        if (quant_positivos > quant_negativos){
            // Se a análise condiz com o numero de estrelas
            if (restaurantes[i].numero_estrelas >= 3.5){
                class_corretos[corretos] = (char*) malloc(100 * sizeof(char));
                strcpy(class_corretos[corretos], restaurantes[i].nome);
                corretos++;
            }
            // Se não
            else {
                class_incorretos[incorretos] = (char*) malloc(100 * sizeof(char));
                strcpy(class_incorretos[incorretos], restaurantes[i].nome);
                incorretos++;
            }
            insere_saida_positiva(restaurantes[i], tam_positivos, tam_negativos, saida_pos, quant_positivos, quant_negativos);
        }

        else if (quant_negativos > quant_positivos){
            if (restaurantes[i].numero_estrelas >= 1.0 && restaurantes[i].numero_estrelas < 2.5){
                class_corretos[corretos] = (char*) malloc(100 * sizeof(char));
                strcpy(class_corretos[corretos], restaurantes[i].nome);
                corretos++;
            }
            else {
                class_incorretos[incorretos] = (char*) malloc(100 * sizeof(char));
                strcpy(class_incorretos[incorretos], restaurantes[i].nome);
                incorretos++;
            }
            insere_saida_negativa(restaurantes[i], tam_positivos, tam_negativos, saida_neg, quant_positivos, quant_negativos);
        }

        else if (quant_negativos == quant_positivos){
            if (restaurantes[i].numero_estrelas >= 2.5 && restaurantes[i].numero_estrelas < 3.5){
                class_corretos[corretos] = (char*) malloc(100 * sizeof(char));
                strcpy(class_corretos[corretos], restaurantes[i].nome);
                corretos++;
            }
            else {
                class_incorretos[incorretos] = (char*) malloc(100 * sizeof(char));
                strcpy(class_incorretos[incorretos], restaurantes[i].nome);
                incorretos++;
            }
            insere_saida_neutra(restaurantes[i], tam_positivos, tam_negativos, saida_neutros, quant_positivos, quant_negativos);
        }


    }
    rewind(saida_pos);
    fclose(saida_pos);
    rewind(saida_neg);
    fclose(saida_neg);
    rewind(saida_neutros);
    fclose(saida_neutros);

    // Imprimindo resultados finais

    FILE *output = fopen("output.txt", "w");

    printf("Restaurantes classificados corretamente: %d\n", corretos);
    fprintf(output, "Restaurantes classificados corretamente: %d\n", corretos);
    for(int l = 0; l < corretos; l++){
        printf("%s\n", class_corretos[l]);
        fprintf(output, "%s\n", class_corretos[l]);
    }
    printf("\n");
    fprintf(output, "\n");
    printf("Restaurantes classificados incorretamente: %d\n", incorretos);
    fprintf(output, "Restaurantes classificados incorretamente: %d\n", incorretos);
    for(int l = 0; l < incorretos; l++){
        printf("%s\n", class_incorretos[l]);
        fprintf(output, "%s\n", class_incorretos[l]);
    }

    corretos = (float) corretos;
    float acuracia = corretos / (float) linhas_reviews;
    printf("\n");
    fprintf(output, "\n");
    printf("Acurácia do modelo: %.2f\n", acuracia);
    fprintf(output, "Acurácia do modelo: %.2f\n", acuracia);

    rewind(output);
    fclose(output);

}