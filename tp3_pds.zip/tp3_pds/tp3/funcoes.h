#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct pessoa{
    char nome[100];
    unsigned int idade;
    int comorbidade;
    struct pessoa *prox; // ponteiro que aponta para o próximo da fila
} Pessoa;


typedef struct fila{
    Pessoa *inicio; // Ponteiro do tipo pessoa que marca o inicio da fila
} Fila;


Pessoa* cria_lista();

Fila* cria_fila();

int conta_linhas(FILE *arquivo);

int determina_prioridade(Pessoa *pessoa);

void coloca_na_fila_em_ordem(Fila *fila, Pessoa *anterior, Pessoa *inicio_lista, Pessoa *pessoa);

Fila* insere_pessoas(FILE *arquivo, Fila *fila);

void imprime_fila(Pessoa *inicio_fila);

int gera_cronograma(FILE *arq_saida, Fila *fila);

void relatorio_final(FILE *arq_saida, Fila *fila);
