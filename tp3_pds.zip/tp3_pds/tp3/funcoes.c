#include "funcoes.h"


Pessoa* cria_lista(){
    return NULL;
}

Fila* cria_fila(){
    Fila *fila = (Fila*) malloc(sizeof(Fila));
    fila->inicio = NULL;
    return fila;
}

// Função auxiliar que conta o número de linhas de um arquivo
int conta_linhas(FILE *arquivo){
    int linhas = 0;
    for(char c = getc(arquivo); c != EOF; c = getc(arquivo)){
        if (c == '\n'){
            linhas++;
        }
    }
    return linhas;
}

int determina_prioridade(Pessoa *pessoa){
    if (pessoa->idade >= 75){
        return 1;
    }
    else if (pessoa->idade >= 60 && pessoa->idade <= 74 && pessoa->comorbidade == 1){
        return 2;
    }
    else if (pessoa->idade >= 60 && pessoa->idade <= 74 && pessoa->comorbidade == 0){
        return 3;
    }
    else if (pessoa->idade >= 18 && pessoa->idade < 60 && pessoa->comorbidade == 1){
        return 4;
    }
    else if (pessoa->idade >= 18 && pessoa->idade < 60 && pessoa->comorbidade == 0){
        return 5;
    }
    // Retorna zero se a pessoa tiver menos de 18 anos
    return 0;
}


// Função recursiva que insere as pessoas no final da fila

void coloca_na_fila_em_ordem(Fila *fila, Pessoa *anterior, Pessoa *inicio_lista, Pessoa *pessoa){

    if (inicio_lista == NULL){
        pessoa->prox = NULL;
        if (inicio_lista == fila->inicio){
            fila->inicio = pessoa;
            return;
        }
        inicio_lista = pessoa;
        anterior->prox = pessoa;
        return;
    }
    int prioridade_pessoa = determina_prioridade(pessoa);
    // Se a pessoa tiver menos de 18 anos, não será colocada na fila, então se isso acontecer, a função vai parar a execução
    // isso acontece quando a função "determina_prioridade()" retorna zero
    if (prioridade_pessoa == 0){
        return;
    }
    // inicio_lista tem que estar preenchido para determinar a prioridade, ou seja, 
    // só pode chamar essa função quando já se verificou que inicio_lista não é nulo
    int prioridade_atual_fila = determina_prioridade(inicio_lista);

    if (prioridade_atual_fila > prioridade_pessoa){
            pessoa->prox = inicio_lista;
            if (inicio_lista == fila->inicio){
                fila->inicio = pessoa;
                return;
            }
            anterior->prox = pessoa;
            return;
    }
    else if (prioridade_atual_fila <= prioridade_pessoa){
        // chamando recursivamente a função
        coloca_na_fila_em_ordem(fila, inicio_lista, inicio_lista->prox, pessoa);
    }
}


Fila* insere_pessoas(FILE *arquivo, Fila *fila){
    int l = conta_linhas(arquivo);
    rewind(arquivo);
    int i = 0;
    while(i < l){
        Pessoa *pessoa = (Pessoa*) malloc(sizeof(Pessoa));
        fscanf(arquivo, "%[^;];%u;%d\n", pessoa->nome, &pessoa->idade, &pessoa->comorbidade);
        coloca_na_fila_em_ordem(fila, NULL, fila->inicio, pessoa);
        i++;
    }
    return fila;
}


void imprime_fila(Pessoa *inicio_fila){
    if (inicio_fila == NULL){
        return;
    }
    if (inicio_fila->prox == NULL){
        printf("%s\n", inicio_fila->nome);
    }
    else{
        printf("%s -> ", inicio_fila->nome);
    }

    imprime_fila(inicio_fila->prox);

}


// Função que insere os dados da fila no arquivo de saída

int gera_cronograma(FILE *arq_saida, Fila *fila){
    // Guardando em uma variável a quantidade total de pessoas que podem ser vacinadas em um dia
    int dia = 0;
    Pessoa *auxiliar = fila->inicio;
    while(auxiliar != NULL){
        dia++;
        fprintf(arq_saida, "Dia %d\n", dia);
        // Iterando em relação às horas e os minutos
        // e colocando um zero antes do número quando necessário (por exemplo, ao invés de "8:00", será colocado um zero antes e ficará "08:00")
        for (int i = 8; i < 17 && auxiliar != NULL; i++){
            for (int j = 0; j < 6 && auxiliar != NULL; j++){
                if (i < 10){
                    fprintf(arq_saida, "0%d:%d0\t%s\t%u\t%d\t%d\n", i, j, auxiliar->nome, auxiliar->idade, auxiliar->comorbidade, determina_prioridade(auxiliar));
                }
                else {
                    fprintf(arq_saida, "%d:%d0\t%s\t%u\t%d\t%d\n", i, j, auxiliar->nome, auxiliar->idade, auxiliar->comorbidade, determina_prioridade(auxiliar));
                }
                auxiliar = auxiliar->prox;

            }
        }
        // Imprimir uma "new line" no arquivo, apenas se tiver mais pessoas pela frente pra imprimir
        if (auxiliar != NULL){
            fprintf(arq_saida, "\n");
        }
    }  
    return dia;  
}


// Função que gera o relatório final do programa

void relatorio_final(FILE *arq_saida, Fila *fila){
    // Dias necessários para vacinar todas as pessoas da fila
    int dias = gera_cronograma(arq_saida, fila);
    // Quantidade de pessoas cadastradas por prioridade
    int quant_pessoas[5]; // referente a quantidade de pessoas cadastradas em cada prioridade
    for(int i = 0; i < 5; i++){
        quant_pessoas[i] = 0;
    }
    int total_pessoas = 0;
    Pessoa *auxiliar = fila->inicio;
    // Contando a quantidade de pessoas cadastradas em cada prioridade
    while(auxiliar != NULL){
        total_pessoas++;
        int prioridade = determina_prioridade(auxiliar);

        switch(prioridade){
            case 1:
                quant_pessoas[0]++;
                break;
            case 2:
                quant_pessoas[1]++;
                break;
            case 3:
                quant_pessoas[2]++;
                break;
            case 4:
                quant_pessoas[3]++;
                break;
            case 5:
                quant_pessoas[4]++;
                break;
            default:
                break;
        }
        auxiliar = auxiliar->prox;
    } 
    FILE *output = fopen("../output/output.txt", "w");

    for (int i = 0; i < 5; i++){
        fprintf(output, "Prioridade %d: %d pessoas\n", i+1, quant_pessoas[i]);
    }
    fprintf(output, "\nTotal de pessoas cadastradas: %d\n", total_pessoas);
    fprintf(output, "Número de dias que serão necessários para vacinar a população: %d\n", dias);

    rewind(output);
    fclose(output);

    for (int i = 0; i < 5; i++){
        printf("Prioridade %d: %d pessoas\n", i+1, quant_pessoas[i]);
    }
    printf("\nTotal de pessoas cadastradas: %d\n", total_pessoas);
    printf("Número de dias que serão necessários para vacinar a população: %d\n", dias);

}