#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"

// gcc -Wall -std=c99 -lm *.c -o tp3
// ./tp3 input.txt

int main(int *argc, char **argv){


    Pessoa *lista = cria_lista();
    Fila *fila = cria_fila();
    fila->inicio = lista;


    FILE *arquivo = fopen(argv[1], "r");
    if (arquivo == NULL){
        printf("Não foi possível abrir o arquivo.\n");
        exit(1);
    }
    fila = insere_pessoas(arquivo, fila);
    rewind(arquivo);
    fclose(arquivo);

    // imprime_fila(fila->inicio);

    // Criando um arquivo com os cronogramas

    FILE *arq_saida = fopen("../output/cronograma.txt", "w");

    relatorio_final(arq_saida, fila);
    
    rewind(arq_saida);
    fclose(arq_saida);

    // Liberando os ponteiros
    Pessoa *aux = fila->inicio;
    do {
        Pessoa *p = aux->prox;
        free(aux);
        aux = p;
    }
    while(aux != NULL);
    free(fila);
    return 0;
}